import streamlit as st
import pandas as pd
from langchain_openai import ChatOpenAI
from langchain.schema import SystemMessage, HumanMessage
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Initialize the AI model
model = ChatOpenAI(model_name="gpt-3.5-turbo", api_key=os.getenv("OPENAI_API_KEY"))

# Sample gym & member data (with start and end dates, status, and money spent)
gyms = {
    "gym123": {"password": "pass123", "name": "FitPro Gym"},
    "gym456": {"password": "pass456", "name": "Iron Warriors"},
}

# Sample gym members data with added fields
gym_members = {
    "gym123": pd.DataFrame([
        {"Member ID": "M001", "Name": "John Doe", "Age": 28, "Plan": "Premium", "Attendance": "15 days", "Start Date": "2023-06-01", "End Date": "2024-06-01", "Status": "Active", "Money Spent in (rupees)": 600},
        {"Member ID": "M002", "Name": "Jane Smith", "Age": 24, "Plan": "Basic", "Attendance": "10 days", "Start Date": "2023-08-15", "End Date": "2024-08-15", "Status": "Active", "Money Spent in (rupees)": 300},
        {"Member ID": "M003", "Name": "Sam Wilson", "Age": 30, "Plan": "Gold", "Attendance": "20 days", "Start Date": "2022-12-01", "End Date": "2024-12-01", "Status": "Inactive", "Money Spent in (rupees)": 900},
        {"Member ID": "M004", "Name": "Sophia Lee", "Age": 26, "Plan": "Premium", "Attendance": "25 days", "Start Date": "2023-02-01", "End Date": "2024-02-01", "Status": "Active", "Money Spent in (rupees)": 650},
        {"Member ID": "M005", "Name": "Michael Brown", "Age": 35, "Plan": "Basic", "Attendance": "12 days", "Start Date": "2023-11-10", "End Date": "2024-11-10", "Status": "Active", "Money Spent in (rupees)": 300},
        {"Member ID": "M006", "Name": "Emma White", "Age": 29, "Plan": "Gold", "Attendance": "18 days", "Start Date": "2023-03-15", "End Date": "2024-03-15", "Status": "Active", "Money Spent in (rupees)": 900},
        {"Member ID": "M007", "Name": "James Green", "Age": 33, "Plan": "Premium", "Attendance": "28 days", "Start Date": "2023-07-01", "End Date": "2024-07-01", "Status": "Active", "Money Spent in (rupees)": 600},
        {"Member ID": "M008", "Name": "Olivia Harris", "Age": 27, "Plan": "Basic", "Attendance": "14 days", "Start Date": "2023-10-25", "End Date": "2024-10-25", "Status": "Inactive", "Money Spent in (rupees)": 300},
        {"Member ID": "M009", "Name": "Liam Clark", "Age": 31, "Plan": "Gold", "Attendance": "22 days", "Start Date": "2022-11-20", "End Date": "2024-11-20", "Status": "Active", "Money Spent in (rupees)": 950},
        {"Member ID": "M010", "Name": "Isabella Lewis", "Age": 25, "Plan": "Basic", "Attendance": "16 days", "Start Date": "2023-12-01", "End Date": "2024-12-01", "Status": "Active", "Money Spent in (rupees)": 300},
        {"Member ID": "M011", "Name": "Ethan Walker", "Age": 29, "Plan": "Premium", "Attendance": "19 days", "Start Date": "2023-04-15", "End Date": "2024-04-15", "Status": "Active", "Money Spent in (rupees)": 600},
        {"Member ID": "M012", "Name": "Mia Young", "Age": 32, "Plan": "Gold", "Attendance": "20 days", "Start Date": "2023-05-10", "End Date": "2024-05-10", "Status": "Inactive", "Money Spent in (rupees)": 950},
        {"Member ID": "M013", "Name": "Noah King", "Age": 27, "Plan": "Premium", "Attendance": "30 days", "Start Date": "2023-09-01", "End Date": "2024-09-01", "Status": "Active", "Money Spent in (rupees)": 600},
        {"Member ID": "M014", "Name": "Charlotte Scott", "Age": 24, "Plan": "Basic", "Attendance": "13 days", "Start Date": "2023-07-05", "End Date": "2024-07-05", "Status": "Active", "Money Spent in (rupees)": 300},
        {"Member ID": "M015", "Name": "Lucas Adams", "Age": 36, "Plan": "Gold", "Attendance": "17 days", "Start Date": "2023-01-20", "End Date": "2024-01-20", "Status": "Active", "Money Spent in (rupees)": 950},
    ]),
    "gym456": pd.DataFrame([
        {"Member ID": "M101", "Name": "Alice Brown", "Age": 26, "Plan": "Basic", "Attendance": "12 days", "Start Date": "2023-09-01", "End Date": "2024-09-01", "Status": "Active", "Money Spent in (rupees)": 350},
        {"Member ID": "M102", "Name": "Bob Johnson", "Age": 32, "Plan": "Premium", "Attendance": "18 days", "Start Date": "2023-05-01", "End Date": "2024-05-01", "Status": "Active", "Money Spent in (rupees)": 700},
        {"Member ID": "M103", "Name": "Sophie Martin", "Age": 29, "Plan": "Basic", "Attendance": "10 days", "Start Date": "2023-06-10", "End Date": "2024-06-10", "Status": "Inactive", "Money Spent in (rupees)": 350},
        {"Member ID": "M104", "Name": "William Clark", "Age": 34, "Plan": "Gold", "Attendance": "20 days", "Start Date": "2023-08-01", "End Date": "2024-08-01", "Status": "Active", "Money Spent in (rupees)" : 950},
        {"Member ID": "M105", "Name": "Emily Lewis", "Age": 25, "Plan": "Premium", "Attendance": "22 days", "Start Date": "2023-07-15", "End Date": "2024-07-15", "Status": "Active", "Money Spent in (rupees)": 700},
        {"Member ID": "M106", "Name": "James Harris", "Age": 40, "Plan": "Basic", "Attendance": "15 days", "Start Date": "2023-05-05", "End Date": "2024-05-05", "Status": "Inactive", "Money Spent in (rupees)": 350},
        {"Member ID": "M107", "Name": "Sarah White", "Age": 28, "Plan": "Gold", "Attendance": "18 days", "Start Date": "2023-03-15", "End Date": "2024-03-15", "Status": "Active", "Money Spent in (rupees)": 950},
        {"Member ID": "M108", "Name": "David Green", "Age": 31, "Plan": "Premium", "Attendance": "24 days", "Start Date": "2023-04-01", "End Date": "2024-04-01", "Status": "Active", "Money Spent in (rupees)": 700},
        {"Member ID": "M109", "Name": "Isabella Brown", "Age": 26, "Plan": "Basic", "Attendance": "19 days", "Start Date": "2023-07-01", "End Date": "2024-07-01", "Status": "Inactive", "Money Spent in (rupees)": 350},
        {"Member ID": "M110", "Name": "Jack Scott", "Age": 38, "Plan": "Gold", "Attendance": "14 days", "Start Date": "2023-09-20", "End Date": "2024-09-20", "Status": "Active", "Money Spent in (rupees)": 950},
    ]),
}

# Streamlit UI
st.title("🏋️ Gym Management System")

# Login section
st.sidebar.header("Gym Owner Login")
gym_id = st.sidebar.text_input("Enter Gym ID:")
password = st.sidebar.text_input("Enter Password:", type="password")
login_button = st.sidebar.button("Login")

if login_button:
    if gym_id in gyms and gyms[gym_id]["password"] == password:
        st.session_state["authenticated"] = True
        st.session_state["gym_id"] = gym_id
        st.session_state["gym_name"] = gyms[gym_id]["name"]
        st.success(f"Welcome, {gyms[gym_id]['name']}!")
        st.rerun()
    else:
        st.error("Invalid Gym ID or Password!")

# If authenticated, show gym details
if "authenticated" in st.session_state and st.session_state["authenticated"]:
    st.subheader(f"🏢 Gym: {st.session_state['gym_name']}")

    # Check if the gym members data is loaded correctly
    gym_data = gym_members.get(st.session_state["gym_id"])
    if gym_data is not None and not gym_data.empty:
        st.subheader("📋 Gym Members")
        
        # Add filtering options
        st.sidebar.header("Filter Members")
        status_filter = st.sidebar.selectbox("Filter by Status", ["All", "Active", "Inactive"])
        plan_filter = st.sidebar.selectbox("Filter by Plan", ["All", "Basic", "Premium", "Gold"])

        # Apply filters
        if status_filter != "All":
            gym_data = gym_data[gym_data["Status"] == status_filter]
        if plan_filter != "All":
            gym_data = gym_data[gym_data["Plan"] == plan_filter]

        st.dataframe(gym_data)

        # Display basic analytics
        st.subheader("📊 Analytics")
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Members", len(gym_data))
        col2.metric("Active Members", len(gym_data[gym_data["Status"] == "Active"]))
        col3.metric("Total Revenue (₹)", gym_data["Money Spent in (rupees)"].sum())

    else:
        st.error("No members data available for this gym.") 

    # Chatbot for answering questions
    if "chat_history" not in st.session_state:
        st.session_state["chat_history"] = []

    st.subheader("💬 Gymbot: Ask Questions")
    question = st.text_input("Ask the Gymbot a question:")

    if question:
        # Append the user's message
        st.session_state["chat_history"].append(HumanMessage(content=question))

        # Construct the conversation history and get a response from the model
        messages = [
            SystemMessage(content=f"You are a gym assistant that answers questions about the gym members, their plans, and other relevant information. Here is the current gym members data:\n{gym_data.to_string()}"),
        ] + st.session_state["chat_history"]

        response = model(messages)
        answer = response.content.strip()

        # Display the response
        st.write(f"Gymbot: {answer}")
        
        # Append the assistant's response
        st.session_state["chat_history"].append(HumanMessage(content=answer))